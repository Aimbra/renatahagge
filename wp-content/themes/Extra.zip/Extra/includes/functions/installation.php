<a href="http://www.elegantthemes.com/gallery/extra/readme.html" target="_blank"><?php esc_html_e( 'Read Extra Documentation', $themename ); ?></a>

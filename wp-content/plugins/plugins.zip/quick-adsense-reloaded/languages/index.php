<?php
/**
 * Do not put custom translations here. They will be deleted on Quick AdSense Reloaded updates.
 *
 * Keep custom QUADS translations in /wp-content/languages/quads
 */
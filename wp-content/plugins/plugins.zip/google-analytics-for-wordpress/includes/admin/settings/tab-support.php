<?php

function monsterinsights_settings_support_tab() {
	echo 'test';
}